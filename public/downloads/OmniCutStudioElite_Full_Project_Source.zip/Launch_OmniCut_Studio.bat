@echo off
title OmniCut Studio Elite v3.0 - Local PC Launcher
echo ========================================================
echo   OmniCut Studio Elite v3.0 - Starting Local Engine
echo ========================================================
echo Checking Node.js environment...
where node >nul 2>nul
if %errorlevel% neq 0 (
    echo [ERROR] Node.js is required to run on Windows.
    echo Please install LTS Node.js from: https://nodejs.org/
    echo Once installed, double-click this file again!
    pause
    exit /b
)
echo Checking dependencies...
if not exist "node_modules\" (
    echo Installing local dependencies...
    call npm install
)
echo Launching OmniCut Studio Elite at http://localhost:3000 ...
start http://localhost:3000
call npm run dev
pause
