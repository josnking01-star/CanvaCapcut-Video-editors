@echo off
title Build Windows .exe - OmniCut Studio Elite
echo ========================================================
echo   Building Standalone Windows x64 Executable (.exe)
echo ========================================================
echo Installing desktop build tools...
call npm install --save-dev electron electron-builder
echo Building client and server...
call npm run build
echo Packaging Windows NSIS installer and portable exe...
call npx electron-builder --windows --x64
echo.
echo ========================================================
echo Complete! Your .exe installer is in: dist_electron/
echo ========================================================
pause
