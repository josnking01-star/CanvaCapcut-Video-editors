# OmniCut Studio Elite v3.0 - Local PC Execution & Build Guide

## 1. Quick Start on Windows PC (Local Execution)
1. Ensure **Node.js 18 or 20+** is installed on your Windows PC from [nodejs.org](https://nodejs.org/).
2. Double-click `Launch_OmniCut_Studio.bat`.
3. It will install packages and automatically open **http://localhost:3000** in your browser!

## 2. How to Build the Standalone Windows .exe File
### Option A: Automated GitHub Actions (Recommended)
1. Push this project to your GitHub repository.
2. Go to **Actions** tab on GitHub -> **Build Windows Native Desktop EXE**.
3. It runs automatically and uploads the **.exe** installer and standalone release artifact!

### Option B: Build .exe Locally on Windows
1. Double-click `Build_Windows_EXE.bat`.
2. Wait for Electron builder to compile the package.
3. Open the newly created `dist_electron/` folder to find your:
   - `OmniCut Studio Elite_Setup_v1.0.0.exe` (NSIS Installer)
   - Portable Standalone `.exe`

## 3. Master Owner Access
- Master Owner Account: `josnking01@gmail.com`
- Supreme Authority with tamper-proof security guards.
